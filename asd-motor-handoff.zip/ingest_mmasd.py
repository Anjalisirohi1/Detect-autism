"""Ingest raw MMASD+ 3D-skeleton CSVs into the same sequence-store format the
Al-Jubouri pipeline already uses, so the downstream training code
(``scripts/summarise_experiments.py``, the collaborator hand-off's
``run_all.py``) needs no changes at all to pick up a second dataset.

This script does not fetch, download, or fabricate any MMASD+ data. It expects
raw CSVs to already exist under ``<root>/data/mmasd_plus/raw/<ActivityFolder>/
processed_*.csv`` -- exactly the layout ``GET_THE_OTHER_DATASET.md`` asks a
human to create by hand, because MMASD+ carries no licence and cannot be
redistributed (``docs/DATA_SHARING.md``, D-005). If that directory does not
exist or is empty, this script says so and exits without error, doing nothing.

Portable by design: this file works unmodified both on the development
machine (``scripts/ingest_mmasd.py``, importing from ``../src``) and inside
the collaborator hand-off bundle (copied to ``<bundle>/ingest_mmasd.py``,
importing from ``./code``), so it can be shipped as code (not data) and run
wherever the raw MMASD+ files actually end up. See ``handoff/
GET_THE_OTHER_DATASET.md`` for the human-facing instructions.

Pipeline, mirroring ``scripts/audit_mmasd.py`` + ``scripts/build_features.py``
+ ``scripts/build_aljubouri.py`` combined into one pass (no intermediate
ragged feature store, matching how ``build_aljubouri.py`` already does this):

1. Parse each filename (``asdmotor.naming``) and read the CSV
   (``asdmotor.dataio``), never raising -- unreadable or unparsable files are
   recorded in ``samples_skipped`` and excluded, not fatal.
2. Recover the true (pre-padding) length and grade geometric integrity
   (``asdmotor.quality``), using the same thresholds as
   ``configs/dataset.yaml`` (bone CV <= 0.05 = coherent). Only coherent
   samples are kept -- see ``docs/MMASD_DATASET_AUDIT.md`` S5 for why this
   check exists and what it catches.
3. Apply the same sample-level filters as ``configs/features.yaml``: drop
   exact byte-duplicates, require at least 30 true frames, require a
   physically plausible torso length (0.25-0.80 m).
4. Normalise (centre + scale + rotate) and build ``pose``/``motor`` features
   over all 7 body regions (``asdmotor.features``), then right-pad to a
   shared masked sequence tensor per (feature_set, region)
   (``asdmotor.sequences``) -- the identical ``values``/``mask``/``lengths``/
   ``sample_ids``/``names`` ``.npz`` layout Al-Jubouri's sequences already use.
5. Write ``manifest.json`` + ``sequence_metadata.csv`` alongside the ``.npz``
   files, so ``handoff/run_all.py``'s existing
   ``MMASD_SEQ_DIR.glob("*.npz")`` detection picks the result up with no
   changes to that file.

The metadata's ``label`` column is set to the activity name. Without it,
``run_all.py`` falls back to ``person_index == 0`` as the target (its default
for any non-``asd_vs_td`` dataset) -- which would silently turn the intended
11-way activity-recognition task into the unrelated, semantically-unverified
person0-vs-rest proxy. Per ``docs/PHASE2_NOTES.md``, MMASD+ has no
typically-developing cohort and must never be used to answer the ASD-vs-TD
question; ``activity`` is the legitimate pipeline-validation target here.

Usage::

    python scripts/ingest_mmasd.py [--raw-dir PATH] [--out-dir PATH]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

# --- import bootstrap: works both on the dev machine (scripts/ + src/) and -----
# --- inside a copied hand-off bundle (bundle-root + code/) --------------------
_HERE = Path(__file__).resolve().parent
if (_HERE / "code").is_dir():
    _SRC = _HERE / "code"          # running as <bundle>/ingest_mmasd.py
    DEFAULT_ROOT = _HERE
else:
    _SRC = _HERE.parent / "src"    # running as <repo>/scripts/ingest_mmasd.py
    DEFAULT_ROOT = _HERE.parent
sys.path.insert(0, str(_SRC))

from asdmotor.dataio import SchemaError, iter_csv_paths, read_skeleton_csv  # noqa: E402
from asdmotor.features import build_features                              # noqa: E402
from asdmotor.naming import FilenameParseError, parse_filename            # noqa: E402
from asdmotor.preprocess import NormalisationSpec, body_scale, normalise  # noqa: E402
from asdmotor.quality import detect_repeat_padding, geometry_metrics, integrity_grade  # noqa: E402
from asdmotor.sequences import pad_sequences                              # noqa: E402
from asdmotor.skeletons import MMASD_PLUS                                 # noqa: E402

DEFAULT_RAW_DIR = DEFAULT_ROOT / "data" / "mmasd_plus" / "raw"
DEFAULT_OUT_DIR = DEFAULT_ROOT / "data" / "mmasd_plus" / "sequences"

FEATURE_SETS = ("pose", "motor")
REGIONS = ("whole_body", "head", "torso", "left_arm", "right_arm", "left_leg", "right_leg")

# Same thresholds already established and justified in configs/dataset.yaml
# (bone-CV grading) and configs/features.yaml (sample-level selection) -- kept
# here rather than re-read from those YAML files so this script has no
# dependency on the dev machine's config layer and can run standalone inside
# a hand-off bundle that never carries configs/.
BONE_CV_CLEAN_THRESHOLD = 0.05
BONE_CV_SUSPECT_THRESHOLD = 0.10
MIN_TRUE_LENGTH = 30
TORSO_LENGTH_RANGE_M = (0.25, 0.80)

#: fps is reported as an interval (25-30), never a point value: the MMASD
#: protocol does not record a per-clip rate (docs/MMASD_DATASET_AUDIT.md S3.1),
#: and inventing a single "fps" number would fabricate precision the source
#: data does not have.
FPS_RANGE = (25.0, 30.0)

#: One row per sample. ``video_id`` is the source-clip identifier (multiple
#: person-tracks can share one); ``frame_id`` has no meaningful per-sample
#: value (MMASD+ carries no per-frame identifier at all -- see the audit,
#: S3.1) and is always empty here. The real per-frame index lives in the
#: companion ``frame_index.parquet`` written alongside the sequence store.
METADATA_COLUMNS = (
    "sample_id", "subject_id", "video_id", "activity", "activity_code", "theme",
    "cohort", "label", "session", "clip_index", "segmentation_flag", "person_index",
    "track_id", "source_file", "sequence_length", "frame_id", "fps_min", "fps_max",
    "duration_s_min", "duration_s_max", "body_scale_m", "bone_cv_median",
    "integrity_grade", "quality_pass", "md5",
)


def assign_cohorts(meta: pd.DataFrame) -> pd.Series:
    """Label each subject by the set of themes they were recorded performing.

    Activities are nested inside subject cohorts in MMASD+
    (docs/MMASD_DATASET_AUDIT.md S7.4); carrying the cohort explicitly stops a
    per-activity result being mistaken for an activity effect alone. Mirrors
    ``scripts/build_features.py::assign_cohorts`` exactly.
    """
    by_subject = meta.groupby("subject_id")["theme"].agg(lambda s: "+".join(sorted(set(s))))
    return meta["subject_id"].map(by_subject)


def process_one(path: Path, root: Path) -> tuple[dict | None, list[np.ndarray] | None, str | None]:
    """Parse, read, quality-check and normalise one raw CSV.

    Returns ``(meta_row, per_frame_normalised_and_world_coords, skip_reason)``
    -- exactly one of the first two is not ``None``. Never raises: every
    failure mode is a skip reason, following the rest of this project's
    "record, never drop silently" convention (e.g. ``build_features.py``).
    """
    sample_id = path.stem
    try:
        parsed = parse_filename(sample_id)
    except FilenameParseError as exc:
        return None, None, f"unparsable_filename: {exc}"

    try:
        sample = read_skeleton_csv(path, strict=True)
    except SchemaError as exc:
        return None, None, f"schema_error: {exc}"
    except Exception as exc:  # noqa: BLE001 - any read failure must be surfaced, not fatal
        return None, None, f"read_error: {type(exc).__name__}: {exc}"

    coords = sample.coords
    true_len = detect_repeat_padding(coords)
    true_coords = coords[:true_len] if true_len >= 2 else coords
    if true_len < MIN_TRUE_LENGTH:
        return None, None, f"too_short: {true_len} < {MIN_TRUE_LENGTH}"

    g = geometry_metrics(true_coords, MMASD_PLUS)
    grade = integrity_grade(g, clean_threshold=BONE_CV_CLEAN_THRESHOLD,
                             suspect_threshold=BONE_CV_SUSPECT_THRESHOLD)
    if grade != "coherent":
        return None, None, f"not_coherent: grade={grade} bone_cv={g.bone_cv_median:.4f}"

    lo, hi = TORSO_LENGTH_RANGE_M
    if not (lo <= g.torso_length_median <= hi):
        return None, None, f"torso_out_of_range: {g.torso_length_median:.3f}m"

    try:
        norm = normalise(true_coords, NormalisationSpec(True, True, True), MMASD_PLUS)
        world = normalise(true_coords, NormalisationSpec(True, True, False), MMASD_PLUS)
        scale = body_scale(true_coords, MMASD_PLUS)
    except ValueError as exc:
        return None, None, f"degenerate_body_scale: {exc}"

    person_index = sample.person_label
    if person_index is None:
        person_index = parsed.person_index_from_name

    row = {
        "sample_id": sample_id,
        "subject_id": parsed.subject_id,
        "video_id": parsed.clip_id,
        "activity": parsed.activity,
        "activity_code": parsed.activity_code,
        "theme": parsed.theme,
        "label": parsed.activity,
        "session": parsed.session,
        "clip_index": parsed.clip_index,
        "segmentation_flag": parsed.segmentation_flag,
        "person_index": person_index,
        "track_id": parsed.track_id,
        "source_file": str(path.relative_to(root)).replace("\\", "/"),
        "sequence_length": true_len,
        "frame_id": None,
        "fps_min": FPS_RANGE[0],
        "fps_max": FPS_RANGE[1],
        "duration_s_min": true_len / FPS_RANGE[1],
        "duration_s_max": true_len / FPS_RANGE[0],
        "body_scale_m": scale,
        "bone_cv_median": g.bone_cv_median,
        "integrity_grade": grade,
        "quality_pass": True,
        "md5": hashlib.md5(path.read_bytes()).hexdigest(),
    }
    return row, [norm, world], None


def run_ingestion(raw_dir: Path, out_dir: Path, log=print) -> dict:
    """Run the full ingestion pipeline. Returns a JSON-serialisable summary.

    Separated from ``main()`` so tests can call it directly against the
    synthetic fixture and inspect the result, without going through argv/CLI.
    """
    raw_dir, out_dir = Path(raw_dir), Path(out_dir)
    if not raw_dir.is_dir():
        log(f"no raw MMASD+ data at {raw_dir} -- nothing to do. "
            f"See handoff/GET_THE_OTHER_DATASET.md.")
        return {"status": "no_raw_data", "raw_dir": str(raw_dir), "n_samples": 0}

    paths = iter_csv_paths(raw_dir, "**/*.csv")
    if not paths:
        log(f"{raw_dir} exists but contains no CSVs -- nothing to do.")
        return {"status": "no_raw_data", "raw_dir": str(raw_dir), "n_samples": 0}

    log(f"discovered {len(paths)} raw CSV(s) under {raw_dir}")

    chunks: dict[tuple[str, str], dict] = {
        (fs, r): {"data": [], "names": None} for fs in FEATURE_SETS for r in REGIONS
    }
    meta_rows: list[dict] = []
    frame_rows: list[pd.DataFrame] = []
    skipped: list[dict] = []
    seen_md5: dict[str, str] = {}

    for i, path in enumerate(paths, 1):
        row, coords_pair, reason = process_one(path, raw_dir)
        if reason is not None:
            skipped.append({"sample_id": path.stem, "reason": reason})
            continue
        if row["md5"] in seen_md5:
            skipped.append({"sample_id": row["sample_id"],
                            "reason": f"exact_duplicate_of: {seen_md5[row['md5']]}"})
            continue
        seen_md5[row["md5"]] = row["sample_id"]

        norm, world = coords_pair
        for fs in FEATURE_SETS:
            for r in REGIONS:
                block = build_features(norm, fs, r, MMASD_PLUS, world_coords=world)
                st = chunks[(fs, r)]
                if st["names"] is None:
                    st["names"] = block.names
                elif st["names"] != block.names:
                    raise RuntimeError(f"feature-name drift in {fs}/{r} at {row['sample_id']}")
                st["data"].append(block.values.astype(np.float32))

        meta_rows.append(row)
        frame_rows.append(pd.DataFrame({
            "sample_id": row["sample_id"], "subject_id": row["subject_id"],
            "activity": row["activity"], "frame_id": np.arange(row["sequence_length"], dtype=np.int32),
        }))
        if i % 250 == 0 or i == len(paths):
            log(f"processed {i}/{len(paths)}")

    if not meta_rows:
        log("no samples survived the geometric-quality and selection filters "
            f"({len(skipped)} skipped) -- nothing written.")
        return {"status": "no_samples_survived", "n_discovered": len(paths),
                "n_skipped": len(skipped), "n_samples": 0}

    meta = pd.DataFrame(meta_rows, columns=list(METADATA_COLUMNS))
    meta["cohort"] = assign_cohorts(meta)
    frames = pd.concat(frame_rows, ignore_index=True)

    lengths = meta["sequence_length"].to_numpy()
    T = int(lengths.max())

    out_dir.mkdir(parents=True, exist_ok=True)
    views: dict[str, dict] = {}
    for (fs, r), st in chunks.items():
        if not st["data"]:
            continue
        seq = pad_sequences(st["data"], list(meta["sample_id"]), st["names"], max_length=T)
        np.savez_compressed(
            out_dir / f"{fs}__{r}.npz",
            values=seq.values, mask=seq.mask, lengths=seq.lengths,
            sample_ids=np.array(seq.sample_ids, dtype=object),
            names=np.array(seq.feature_names, dtype=object),
        )
        views[f"{fs}__{r}"] = {"shape": list(seq.values.shape), "n_features": seq.n_features}
        log(f"wrote {fs}__{r}: {tuple(seq.values.shape)}")

    meta.to_csv(out_dir / "sequence_metadata.csv", index=False)
    try:
        frames.to_parquet(out_dir / "frame_index.parquet", index=False)
    except ImportError:
        log("pyarrow not available -- skipped frame_index.parquet (sequence_metadata.csv "
            "and the .npz stores are unaffected)")

    manifest = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "dataset": "mmasd_plus",
        "licence": "none stated - not redistributed (docs/DATA_SHARING.md, D-005)",
        "task_kind": "pipeline_validation_proxy",
        "note": "MMASD+ has no typically-developing cohort and is never a second "
                "ASD-vs-TD dataset - see docs/PHASE2_NOTES.md. label = activity.",
        "skeleton": MMASD_PLUS.name,
        "normalisation": "centre+scale+rotate",
        "policy": {
            "windowing": "none - one sequence per recording",
            "padding": "right zero-padding with an explicit boolean mask",
            "normalisation_here": "centre+scale+rotate applied at ingestion time "
                                  "(unlike Al-Jubouri, MMASD+ has no per-fold "
                                  "re-fit requirement upstream of this store)",
            "quality_filter": f"bone_cv_median <= {BONE_CV_CLEAN_THRESHOLD} "
                              "(docs/MMASD_DATASET_AUDIT.md S5)",
            "selection": {
                "min_true_length": MIN_TRUE_LENGTH,
                "torso_length_range_m": list(TORSO_LENGTH_RANGE_M),
                "drop_exact_duplicates": True,
            },
        },
        "max_length": T,
        "n_samples": int(len(meta)),
        "n_subjects": int(meta["subject_id"].nunique()),
        "n_discovered": len(paths),
        "n_skipped": len(skipped),
        "samples_skipped": skipped,
        "activities": {k: int(v) for k, v in meta["activity"].value_counts().items()},
        "cohorts": {k: int(v) for k, v in meta["cohort"].value_counts().items()},
        "length_stats": {
            "min": int(lengths.min()), "max": int(lengths.max()),
            "mean": float(lengths.mean()), "median": float(np.median(lengths)),
        },
        "views": views,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    log(f"samples={len(meta)} subjects={meta['subject_id'].nunique()} "
        f"activities={meta['activity'].nunique()} skipped={len(skipped)} T={T}")
    return {"status": "ok", **{k: manifest[k] for k in
            ("n_samples", "n_subjects", "n_discovered", "n_skipped", "max_length")},
            "out_dir": str(out_dir), "views": list(views)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw-dir", default=str(DEFAULT_RAW_DIR))
    ap.add_argument("--out-dir", default=str(DEFAULT_OUT_DIR))
    args = ap.parse_args()

    summary = run_ingestion(Path(args.raw_dir), Path(args.out_dir))
    return 0 if summary["status"] in ("ok", "no_raw_data") else 1


if __name__ == "__main__":
    raise SystemExit(main())
