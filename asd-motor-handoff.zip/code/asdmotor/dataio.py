"""Reading MMASD+ 3D-skeleton CSVs into arrays, with schema validation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .skeleton import COORD_COLUMNS, LABEL_COLUMNS, N_JOINTS


class SchemaError(ValueError):
    """The CSV does not have the expected MMASD+ skeleton schema."""


@dataclass(frozen=True, slots=True)
class SkeletonSample:
    """One person-track cut from one source clip.

    Attributes:
        path: file the sample was read from.
        coords: ``(T, 25, 3)`` float array of landmark coordinates.
        action_label: per-file activity code as an integer, from ``Action_Label``.
        person_label: per-file person index, from the column the dataset names
            ``ASD_Label``. See the audit report - despite the name this is a
            within-clip person identifier, not an ASD diagnosis.
        action_label_constant: whether ``Action_Label`` was constant down the file.
        person_label_constant: whether ``ASD_Label`` was constant down the file.
        n_missing: count of NaN cells across all 77 columns.
    """

    path: Path
    coords: np.ndarray
    action_label: int | None
    person_label: int | None
    action_label_constant: bool
    person_label_constant: bool
    n_missing: int

    @property
    def n_frames(self) -> int:
        return int(self.coords.shape[0])


def read_skeleton_csv(path: str | Path, *, strict: bool = True) -> SkeletonSample:
    """Read one MMASD+ skeleton CSV.

    Args:
        path: CSV path.
        strict: if True, raise :class:`SchemaError` when the columns differ from
            the expected 75 coordinates + 2 labels. If False, coordinates are
            taken positionally from the first 75 columns.

    Raises:
        SchemaError: on schema mismatch when *strict*.
    """
    path = Path(path)
    df = pd.read_csv(path)
    expected = list(COORD_COLUMNS) + list(LABEL_COLUMNS)
    if list(df.columns) != expected:
        if strict:
            raise SchemaError(
                f"{path.name}: unexpected columns "
                f"({len(df.columns)} found, {len(expected)} expected)"
            )
        if df.shape[1] < len(COORD_COLUMNS):
            raise SchemaError(f"{path.name}: only {df.shape[1]} columns")

    n_missing = int(df.isna().to_numpy().sum())
    coords = df.iloc[:, : len(COORD_COLUMNS)].to_numpy(dtype=float)
    coords = coords.reshape(len(df), N_JOINTS, 3)

    def _label(col: str) -> tuple[int | None, bool]:
        if col not in df.columns:
            return None, False
        u = pd.unique(df[col].dropna())
        if len(u) == 0:
            return None, False
        return int(u[0]), bool(len(u) == 1)

    action, action_const = _label("Action_Label")
    person, person_const = _label("ASD_Label")
    return SkeletonSample(
        path=path,
        coords=coords,
        action_label=action,
        person_label=person,
        action_label_constant=action_const,
        person_label_constant=person_const,
        n_missing=n_missing,
    )


def iter_csv_paths(root: Path, pattern: str = "**/*.csv") -> list[Path]:
    """All dataset CSVs under *root*, sorted, excluding notebook checkpoints."""
    return sorted(
        p
        for p in root.glob(pattern)
        if p.is_file() and ".ipynb_checkpoints" not in p.parts
    )
