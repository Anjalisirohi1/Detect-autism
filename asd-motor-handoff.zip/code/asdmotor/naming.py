"""Parsing of MMASD+ 3D-skeleton CSV filenames.

Filenames look like::

    processed_<activity_code>_<subject_id>_D<session>_<clip>_<flag>_<track>_<person>.csv
    processed_Arm_swing<activity_code>_...          # Arm_Swing folder only

Every field below was verified against all 3,276 files in the release (see
``docs/MMASD_DATASET_AUDIT.md``). Known irregularities that the parser tolerates
explicitly, rather than silently:

* a stray space before the track field (``..._i _26_0``);
* a trailing ``" (1)"`` added by a browser download of a duplicate name;
* a third numeric token after the person index (``..._5_1_2``);
* a missing person index (three files) - the authoritative person index is the
  ``ASD_Label`` column, not the filename.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Final

#: activity code -> (canonical activity name, theme), from the MMASD repository
#: README and the MMASD+ paper (Table 1).
ACTIVITY_CODES: Final[dict[str, tuple[str, str]]] = {
    "as": ("arm_swing", "robot"),
    "bs": ("body_swing", "robot"),
    "ce": ("chest_expansion", "robot"),
    "sq": ("squat", "robot"),
    "dr": ("drumming", "rhythm"),
    "mfs": ("maracas_forward_shaking", "rhythm"),
    "ms": ("maracas_shaking", "rhythm"),
    "sac": ("sing_and_clap", "rhythm"),
    "fg": ("frog_pose", "yoga"),
    "tr": ("tree_pose", "yoga"),
    "tw": ("twist_pose", "yoga"),
}

#: Folder name on disk -> activity code. Verified to be 1:1 with the code parsed
#: out of every filename inside that folder.
FOLDER_TO_CODE: Final[dict[str, str]] = {
    "Arm_Swing": "as",
    "Body_pose": "bs",
    "chest_expansion": "ce",
    "Squat_Pose": "sq",
    "Drumming": "dr",
    "Marcas_Forward": "mfs",
    "Marcas_Shaking": "ms",
    "Sing_Clap": "sac",
    "Frog_Pose": "fg",
    "Tree_Pose": "tr",
    "Twist_Pose": "tw",
}

#: Integer value of the ``Action_Label`` column -> activity code. Verified to be
#: perfectly consistent with the folder and the filename code for all files.
ACTION_LABEL_TO_CODE: Final[dict[int, str]] = {
    0: "as",
    1: "bs",
    2: "ce",
    3: "fg",
    4: "dr",
    5: "mfs",
    6: "ms",
    7: "sac",
    8: "sq",
    9: "tr",
    10: "tw",
}

# Longest codes first so that "mfs"/"sac" win over "ms"/"as".
_CODE_ALT = "|".join(sorted(ACTIVITY_CODES, key=len, reverse=True))

_PATTERN = re.compile(
    r"^processed_"
    r"(?P<prefix>.*?)"                       # optional human-readable activity prefix
    r"(?P<code>" + _CODE_ALT + r")_"
    r"(?P<subject>\d+)_"
    r"D(?P<session>\d+)_"
    r"(?P<clip>\d+)_"
    r"(?P<flag>[yni])"
    r"\s*_"                                  # stray space tolerated
    r"(?P<tail>[0-9_]+?)"
    r"(?P<dupmark>\s*\(\d+\))?$"
)


@dataclass(frozen=True, slots=True)
class ParsedName:
    """Structured view of one MMASD+ skeleton filename."""

    stem: str
    activity_code: str
    activity: str
    theme: str
    subject_id: str
    session: str
    clip_index: str
    segmentation_flag: str
    track_id: int | None
    person_index_from_name: int | None
    extra_tokens: tuple[str, ...]
    duplicate_download_marker: bool
    name_prefix: str

    @property
    def clip_id(self) -> str:
        """Identifier of the source MMASD video clip this person was cut from."""
        return (
            f"{self.activity_code}_{self.subject_id}_D{self.session}"
            f"_{self.clip_index}_{self.segmentation_flag}"
        )

    def as_dict(self) -> dict[str, object]:
        d = asdict(self)
        d["extra_tokens"] = "|".join(self.extra_tokens)
        d["clip_id"] = self.clip_id
        return d


class FilenameParseError(ValueError):
    """Raised when a filename does not match the MMASD+ convention at all."""


def parse_filename(stem: str) -> ParsedName:
    """Parse a filename stem (no ``.csv``) into its fields.

    Raises:
        FilenameParseError: if the stem does not follow the convention. Callers
            should record the file as ``status=unparsable`` rather than drop it.
    """
    m = _PATTERN.match(stem)
    if m is None:
        raise FilenameParseError(f"filename does not match MMASD+ convention: {stem!r}")

    tokens = [t for t in m.group("tail").split("_") if t]
    track = int(tokens[0]) if tokens else None
    person = int(tokens[1]) if len(tokens) > 1 else None
    extra = tuple(tokens[2:])

    code = m.group("code")
    activity, theme = ACTIVITY_CODES[code]
    return ParsedName(
        stem=stem,
        activity_code=code,
        activity=activity,
        theme=theme,
        subject_id=m.group("subject"),
        session=m.group("session"),
        clip_index=m.group("clip"),
        segmentation_flag=m.group("flag"),
        track_id=track,
        person_index_from_name=person,
        extra_tokens=extra,
        duplicate_download_marker=m.group("dupmark") is not None,
        name_prefix=m.group("prefix"),
    )
